package com.example.service;

public class LoggingService {

    public LoggingService() {
        System.out.println("LoggingService created");
    }

    public void login() {
        System.out.println();
        System.out.println("Logging in Successful");
    }
}
