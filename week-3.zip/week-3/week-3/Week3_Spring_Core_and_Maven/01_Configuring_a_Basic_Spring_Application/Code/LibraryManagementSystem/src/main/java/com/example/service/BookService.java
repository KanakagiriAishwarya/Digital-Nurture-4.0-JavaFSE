package com.example.service;

public class BookService {

    public BookService() {
        System.out.println("This is BookService");
    }
}
