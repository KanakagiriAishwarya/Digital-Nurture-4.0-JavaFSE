package com.example.repository;

public class BookRepository {

    public  BookRepository() {
        System.out.println("This is BookRepository");
    }
}
